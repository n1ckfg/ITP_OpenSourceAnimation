INSTALLATION : 

D�zippez le contenu de l'archive dans le dossier Support Files/Scripts de After Effects.


INFO :
http://www.duduf.net
