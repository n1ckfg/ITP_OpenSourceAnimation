{

var foo = comp.layer("bob");
var p = foo.property("position");
p.setValue(Math.random()*100);

}