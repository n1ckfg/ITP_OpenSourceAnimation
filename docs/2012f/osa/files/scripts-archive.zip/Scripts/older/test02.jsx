{  //start script
	app.beginUndoGroup("foo");

	var comp = app.project.item(1);
	var sW = comp.width;
	var sH = comp.height;

	for(var i=0;i<100;i++){
		var solid = comp.layers.addSolid([1.0,1.0,0], "my square", 50,50, 1);
		solid.motionBlur = true;

		var p = solid.property("position");
		var t = solid.property("opacity");

		t.setValue(Math.random()*100);

		for(var j=0;j<10;j++){
			p.setValueAtTime(j,[Math.random()*sW,Math.random()*sH]);
		}
	}

	app.endUndoGroup();
}  //end script